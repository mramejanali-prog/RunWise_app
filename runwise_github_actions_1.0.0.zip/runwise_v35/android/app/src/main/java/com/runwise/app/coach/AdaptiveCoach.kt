package com.runwise.app.coach

import com.runwise.app.data.*
import java.time.*
import kotlin.math.max
import kotlin.math.min

/** Deterministic coaching engine for v0.2. It is deliberately explainable and testable. */
object AdaptiveCoach {
    data class AthleteState(
        val weeklyKm: Double,
        val previousWeeklyKm: Double,
        val sessionsLast14d: Int,
        val hardSessionsLast7d: Int,
        val easySessionsLast7d: Int,
        val daysSinceLastRun: Long?,
        val nextRaceDays: Long?,
        val nextRaceDistanceKm: Double?,
        val loadScore: Int,
        val recommendation: String
    )

    fun assess(activities: List<ActivityEntity>, races: List<RaceEntity>, now: Instant = Instant.now()): AthleteState {
        val currentStart = now.minus(7, java.time.temporal.ChronoUnit.DAYS).toEpochMilli()
        val previousStart = now.minus(14, java.time.temporal.ChronoUnit.DAYS).toEpochMilli()
        val current = activities.filter { it.startedAtEpochMs >= currentStart }
        val previous = activities.filter { it.startedAtEpochMs in previousStart until currentStart }
        val weeklyKm = current.sumOf { it.distanceMeters } / 1000.0
        val previousKm = previous.sumOf { it.distanceMeters } / 1000.0
        val hard = current.count { it.avgPaceSecondsPerKm != null && it.avgPaceSecondsPerKm!! < easyPaceThreshold(current) }
        val easy = current.size - hard
        val last = activities.maxByOrNull { it.startedAtEpochMs }
        val daysSince = last?.let { Duration.between(Instant.ofEpochMilli(it.startedAtEpochMs), now).toDays().coerceAtLeast(0) }
        val next = races.filter { it.dateEpochMs > now.toEpochMilli() }.minByOrNull { it.dateEpochMs }
        val raceDays = next?.let { Duration.between(now, Instant.ofEpochMilli(it.dateEpochMs)).toDays() }
        val ratio = if (previousKm > 0) weeklyKm / previousKm else 1.0
        val load = (50 + ((ratio - 1.0) * 45) + hard * 8 - (if ((daysSince ?: 0) >= 3) 8 else 0)).toInt().coerceIn(0,100)
        val rec = when {
            load >= 80 -> "Carga elevada: prioriza recuperação e evita dois treinos intensos consecutivos."
            raceDays != null && raceDays <= 7 -> "Semana de prova: reduz volume e preserva alguma intensidade curta."
            daysSince != null && daysSince >= 3 -> "Retoma progressivamente com uma corrida fácil antes de intensidade."
            ratio > 1.15 -> "Volume subiu rapidamente: mantém ou reduz ligeiramente esta semana."
            else -> "Carga equilibrada: podes progredir de forma gradual."
        }
        return AthleteState(weeklyKm, previousKm, current.size.coerceAtMost(99), hard, easy, daysSince, raceDays, next?.distanceMeters?.div(1000.0), load, rec)
    }

    fun generateWeek(state: AthleteState, weekStart: LocalDate, baselinePaceSecKm: Double? = null): List<PlannedWorkoutEntity> {
        val safeWeekly = when {
            state.loadScore >= 80 -> max(15.0, state.weeklyKm * 0.85)
            state.weeklyKm <= 0 -> 20.0
            else -> min(state.weeklyKm * 1.08, state.weeklyKm + 8.0)
        }
        val easyPace = baselinePaceSecKm ?: 390.0
        val qualityPace = easyPace * 0.88
        val longKm = safeWeekly * 0.35
        val easyKm = safeWeekly * 0.18
        val workouts = mutableListOf<PlannedWorkoutEntity>()
        fun add(day: Int, type: WorkoutType, title: String, desc: String, km: Double?, paceMin: Double? = null, paceMax: Double? = null) {
            val date = weekStart.plusDays(day.toLong())
            workouts += PlannedWorkoutEntity(
                id = "coach-${date}-${type.name}", dateEpochMs = date.atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli(),
                type = type, title = title, description = desc, targetDistanceMeters = km?.times(1000),
                targetDurationSeconds = null, targetPaceMinSecondsPerKm = paceMin, targetPaceMaxSecondsPerKm = paceMax,
                generatedReason = state.recommendation
            )
        }
        add(0, WorkoutType.EASY, "Corrida fácil", "Ritmo conversável, foco em técnica e economia.", easyKm, easyPace * 1.05, easyPace * 1.20)
        add(1, WorkoutType.RECOVERY, "Recuperação", "Descanso ativo ou caminhada/mobilidade leve.", null)
        add(2, WorkoutType.INTERVALS, "Intervalos", "Aquecimento + 6 x 3 min controlados / 2 min trote + retorno à calma.", safeWeekly * 0.16, qualityPace * 0.95, qualityPace * 1.05)
        add(3, WorkoutType.REST, "Descanso", "Sem corrida. Prioriza sono e recuperação.", null)
        add(4, WorkoutType.TEMPO, "Tempo run", "Aquecimento + bloco sustentado, sem sprintar + retorno à calma.", safeWeekly * 0.18, easyPace * 0.92, easyPace * 1.00)
        add(5, WorkoutType.RECOVERY, "Recuperação", "Corrida muito leve opcional ou descanso.", safeWeekly * 0.10, easyPace * 1.10, easyPace * 1.25)
        add(6, WorkoutType.LONG_RUN, "Longão", "Ritmo confortável e constante. Não transformar em prova.", longKm, easyPace * 1.05, easyPace * 1.18)
        return workouts
    }

    private fun easyPace(activities: List<ActivityEntity>): Double = easyPaceThreshold(activities)
    private fun easyPaceThreshold(activities: List<ActivityEntity>): Double {
        val paces = activities.mapNotNull { it.avgPaceSecondsPerKm }.filter { it > 180 && it < 900 }
        return if (paces.isEmpty()) 420.0 else paces.sorted()[paces.size / 2]
    }
}
