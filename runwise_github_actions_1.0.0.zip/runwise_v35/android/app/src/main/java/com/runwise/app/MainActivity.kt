package com.runwise.app

import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.content.pm.PackageManager
import android.Manifest
import androidx.core.app.ActivityCompat
import com.runwise.app.content.RunWiseContent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.ActivityResultLauncher
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.health.connect.client.PermissionController
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.runwise.app.sync.CloudSyncWorker
import com.runwise.app.sync.DailyMotivationWorker
import java.util.concurrent.TimeUnit
import com.runwise.app.data.*
import com.runwise.app.analysis.ExecutionAnalysis
import com.runwise.app.ui.MainViewModel
import java.time.*

class MainActivity : ComponentActivity() {
    private lateinit var permissionLauncher: ActivityResultLauncher<Set<String>>
    private lateinit var notificationPermissionLauncher: ActivityResultLauncher<String>
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        permissionLauncher = registerForActivityResult(PermissionController.createRequestPermissionResultContract()) { }
        notificationPermissionLauncher = registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.RequestPermission()) { }
        scheduleCloudSync()
        scheduleDailyMotivation()
        if (android.os.Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        setContent { RunWiseApp() }
    }


    private fun scheduleDailyMotivation() {
        val request = PeriodicWorkRequestBuilder<DailyMotivationWorker>(24, TimeUnit.HOURS).build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork("runwise-daily-motivation", ExistingPeriodicWorkPolicy.UPDATE, request)
    }

    private fun scheduleCloudSync() {
        val request = PeriodicWorkRequestBuilder<CloudSyncWorker>(6, TimeUnit.HOURS)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "runwise-cloud-sync", ExistingPeriodicWorkPolicy.UPDATE, request
        )
    }

    @Composable private fun RunWiseApp(vm: MainViewModel = viewModel()) {
        val activities by vm.activities.collectAsState()
        val races by vm.races.collectAsState()
        val goals by vm.goals.collectAsState()
        val planned by vm.planned.collectAsState()
        val executions by vm.executions.collectAsState()
        val state by vm.coachState.collectAsState()
        val reports by vm.reports.collectAsState()
        val message by vm.message.collectAsState()
        val motivation by vm.dailyMotivation.collectAsState()
        val loggedIn by vm.loggedIn.collectAsState()
        val conflicts by vm.conflicts.collectAsState()
        val pendingSync by vm.pendingSyncCount.collectAsState()
        val conflictCount by vm.conflictCount.collectAsState()
        val lastSync by vm.lastSyncEpochMs.collectAsState()
        var tab by remember { mutableIntStateOf(0) }
        var selectedWorkout by remember { mutableStateOf<PlannedWorkoutEntity?>(null) }
        MaterialTheme {
            if (!loggedIn) {
                AuthScreen(vm)
                return@MaterialTheme
            }
            Scaffold(bottomBar = { NavigationBar {
                listOf("Resumo","Treinos","Provas","Treinador","Relatórios","Sync", "Vídeos").forEachIndexed { i, label ->
                    NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = {}, label = { Text(label) })
                }
            }}) { pad ->
                Column(Modifier.fillMaxSize().padding(pad).padding(16.dp)) {
                    Text("RunWise", style = MaterialTheme.typography.headlineMedium)
                    Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(14.dp)) {
                        Text("Motivação de hoje", style = MaterialTheme.typography.titleMedium)
                        Text(motivation)
                    } }
                    Text(message, style = MaterialTheme.typography.bodyMedium)
                    Spacer(Modifier.height(12.dp))
                    when(tab) {
                        0 -> Dashboard(activities, state, goals, vm)
                        1 -> TrainingList(activities)
                        2 -> RaceList(races)
                        3 -> CoachScreen(state, planned, vm, onOpen = { selectedWorkout = it })
                        4 -> ReportList(reports)
                        5 -> SyncCenter(conflicts, pendingSync, conflictCount, lastSync, vm)
                        6 -> VideoLibrary()
                    }
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { permissionLauncher.launch(vm.healthRepository().permissions) }) { Text("Ligar Health Connect") }
                        OutlinedButton(onClick = { vm.syncHealthConnect() }) { Text("Sincronizar") }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = {
                            if (checkSelfPermission(android.Manifest.permission.WRITE_CALENDAR) == PackageManager.PERMISSION_GRANTED) vm.exportPlanToCalendar()
                            else ActivityCompat.requestPermissions(this@MainActivity, arrayOf(android.Manifest.permission.READ_CALENDAR, android.Manifest.permission.WRITE_CALENDAR), 1001)
                        }) { Text("Enviar plano para calendário") }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { vm.syncCloud() }) { Text("Sincronizar cloud") }
                        TextButton(onClick = { vm.logout() }) { Text("Sair") }
                    }
                    Spacer(Modifier.height(8.dp))
                    if (tab != 6) TextButton(onClick = { tab = 6 }) { Text("Central de sincronização") }
                }
            }
            selectedWorkout?.let { w -> WorkoutDetail(w, executions.firstOrNull { it.workoutId == w.id }, vm, onClose = { selectedWorkout = null }) }
        }
    }

    @Composable private fun AuthScreen(vm: MainViewModel) {
        var email by remember { mutableStateOf("") }
        var password by remember { mutableStateOf("") }
        var register by remember { mutableStateOf(false) }
        var serverUrl by remember { mutableStateOf(vm.apiBaseUrl()) }
        Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
            Text("RunWise", style = MaterialTheme.typography.displaySmall)
            Spacer(Modifier.height(8.dp))
            Text(if (register) "Cria a tua conta de atleta" else "Entra na tua conta")
            Spacer(Modifier.height(20.dp))
            OutlinedTextField(serverUrl, { serverUrl = it }, label = { Text("Servidor API") }, placeholder = { Text("https://api.exemplo.com") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            TextButton(onClick = { vm.setApiBaseUrl(serverUrl.trim()) }) { Text("Guardar servidor") }
            OutlinedTextField(email, { email = it }, label = { Text("Email") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(password, { password = it }, label = { Text("Palavra-passe") }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(16.dp))
            Button(
                enabled = email.contains("@") && password.length >= 6,
                onClick = { if (register) vm.register(email, password) else vm.login(email, password) },
                modifier = Modifier.fillMaxWidth()
            ) { Text(if (register) "Criar conta" else "Entrar") }
            TextButton(onClick = { register = !register }) {
                Text(if (register) "Já tenho conta" else "Criar uma conta")
            }
        }
    }

    @Composable private fun Dashboard(a: List<ActivityEntity>, state: com.runwise.app.coach.AdaptiveCoach.AthleteState, goals: List<GoalEntity>, vm: MainViewModel) {
        val weekKm = state.weeklyKm
        Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp)) {
            Text("Estado do atleta", style = MaterialTheme.typography.titleLarge)
            Text("Carga: ${state.loadScore}/100")
            Text("Esta semana: %.1f km".format(weekKm))
            Text("Semana anterior: %.1f km".format(state.previousWeeklyKm))
            Text("Sessões: ${state.sessionsLast14d} nos últimos 14 dias")
            Text(state.recommendation)
            if (state.nextRaceDays != null) Text("Próxima prova: ${state.nextRaceDays} dias • ${state.nextRaceDistanceKm ?: 0.0} km")
        } }
        Spacer(Modifier.height(8.dp))
        GoalSection(goals, vm)
    }

    @Composable private fun GoalSection(goals: List<GoalEntity>, vm: MainViewModel) {
        var name by remember { mutableStateOf("") }
        var target by remember { mutableStateOf("") }
        var unit by remember { mutableStateOf("km") }
        Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Objetivos", style = MaterialTheme.typography.titleLarge)
            goals.take(3).forEach { goal -> Text("${goal.name}: ${goal.currentValue} / ${goal.targetValue} ${goal.unit}") }
            OutlinedTextField(name, { name = it }, label = { Text("Novo objetivo") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(target, { target = it }, label = { Text("Meta") }, singleLine = true, modifier = Modifier.weight(1f))
                OutlinedTextField(unit, { unit = it }, label = { Text("Unidade") }, singleLine = true, modifier = Modifier.weight(1f))
            }
            Button(onClick = {
                val value = target.replace(',', '.').toDoubleOrNull()
                if (name.isNotBlank() && value != null && value > 0) {
                    vm.saveGoal(name.trim(), value, unit.trim().ifBlank { "km" })
                    name = ""; target = ""
                }
            }) { Text("Criar objetivo") }
        } }
    }

    @Composable private fun TrainingList(items: List<ActivityEntity>) { LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) { items(items) { a ->
        ListItem(headlineContent={Text(a.title ?: "Corrida")}, supportingContent={Text("%.2f km • %.1f min/km".format(a.distanceMeters/1000.0, (a.avgPaceSecondsPerKm ?: 0.0)/60.0))}, trailingContent={Text(a.kind.name)})
    } } }

    @Composable private fun RaceList(items: List<RaceEntity>) { LazyColumn { items(items) { r -> ListItem(headlineContent={Text(r.name)}, supportingContent={Text("${r.provider} • ${r.location ?: "local não definido"}")}, trailingContent={Text(r.registrationStatus)}) } } }

    @Composable private fun CoachScreen(state: com.runwise.app.coach.AdaptiveCoach.AthleteState, workouts: List<PlannedWorkoutEntity>, vm: MainViewModel, onOpen: (PlannedWorkoutEntity) -> Unit) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp)) { Text("Treinador pessoal", style=MaterialTheme.typography.titleLarge); Text(state.recommendation); Text("Carga atual: ${state.loadScore}/100") } }
            Button(onClick={vm::generateCurrentPlan}) { Text("Gerar / adaptar plano desta semana") }
            workouts.take(7).forEach { w ->
                Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(w.title, style=MaterialTheme.typography.titleMedium)
                    Text(w.description)
                    Text(java.time.Instant.ofEpochMilli(w.dateEpochMs).atZone(java.time.ZoneId.systemDefault()).toLocalDate().toString())
                    w.targetDistanceMeters?.let { Text("Distância alvo: %.1f km".format(it/1000.0)) }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick={ onOpen(w) }) { Text("Abrir treino") }
                        if (!w.completed) OutlinedButton(onClick={ { vm.completeWorkout(w.id) } }) { Text("Concluído") }
                        if (!w.skipped) OutlinedButton(onClick={ { vm.skipWorkout(w.id) } }) { Text("Saltar") }
                    }
                    if (w.completed) Text("✓ Concluído", color = MaterialTheme.colorScheme.primary)
                    if (w.skipped) Text("↷ Saltado", color = MaterialTheme.colorScheme.error)
                } }
            }
        }
    }

    @Composable private fun WorkoutDetail(workout: PlannedWorkoutEntity, execution: WorkoutExecutionEntity?, vm: MainViewModel, onClose: () -> Unit) {
        var distance by remember(execution?.workoutId) { mutableStateOf(execution?.actualDistanceMeters?.let { (it / 1000.0).toString() } ?: "") }
        var duration by remember(execution?.workoutId) { mutableStateOf(execution?.actualDurationSeconds?.let { (it / 60.0).toString() } ?: "") }
        var pace by remember(execution?.workoutId) { mutableStateOf(execution?.actualAvgPaceSecondsPerKm?.let { (it / 60.0).toString() } ?: "") }
        var hr by remember(execution?.workoutId) { mutableStateOf(execution?.actualAvgHeartRate?.toString() ?: "") }
        var rpe by remember(execution?.workoutId) { mutableStateOf(execution?.perceivedEffort?.toString() ?: "") }
        var notes by remember(execution?.workoutId) { mutableStateOf(execution?.notes ?: "") }
        AlertDialog(
            onDismissRequest = onClose,
            title = { Text(workout.title) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(workout.description)
                    Text("Execução", style = MaterialTheme.typography.titleMedium)
                    Text("1. Aquecimento — 10 a 15 min muito fácil + mobilidade dinâmica.")
                    Text(workout.type.executionBlock())
                    Text("3. Recuperação — ${workout.type.recoveryBlock()}")
                    Text("4. Desaquecimento — 8 a 10 min fácil.")
                    workout.targetDistanceMeters?.let { Text("Volume alvo: %.1f km".format(it / 1000.0)) }
                    workout.targetDurationSeconds?.let { Text("Duração alvo: ${it / 60} min") }
                    val min = workout.targetPaceMinSecondsPerKm; val max = workout.targetPaceMaxSecondsPerKm
                    if (min != null || max != null) Text("Ritmo alvo: ${paceText(min)}${if (min != null && max != null) " – " else ""}${paceText(max)} min/km")
                    workout.generatedReason?.let { Text("Porquê este treino: $it") }
                    HorizontalDivider()
                    Text("O que realmente fizeste", style = MaterialTheme.typography.titleMedium)
                    OutlinedTextField(distance, { distance = it }, label = { Text("Distância real (km)") }, singleLine = true)
                    OutlinedTextField(duration, { duration = it }, label = { Text("Tempo real (min)") }, singleLine = true)
                    OutlinedTextField(pace, { pace = it }, label = { Text("Ritmo médio (min/km)") }, singleLine = true)
                    OutlinedTextField(hr, { hr = it }, label = { Text("FC média (bpm)") }, singleLine = true)
                    OutlinedTextField(rpe, { rpe = it }, label = { Text("Esforço percebido (1–10)") }, singleLine = true)
                    OutlinedTextField(notes, { notes = it }, label = { Text("Notas") }, minLines = 2)
                    if (execution != null) Text("✓ Execução já registada", color = MaterialTheme.colorScheme.primary)
                    if (execution != null) {
                        val analysis = ExecutionAnalysis.analyze(workout, execution)
                        Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("Análise da execução", style = MaterialTheme.typography.titleMedium)
                            Text("${analysis.status} • ${analysis.score}/100")
                            Text(analysis.explanation)
                            analysis.distanceDeltaPct?.let { Text("Distância: ${if (it >= 0) "+" else ""}${"%.1f".format(it)}% vs alvo") }
                            analysis.durationDeltaPct?.let { Text("Duração: ${if (it >= 0) "+" else ""}${"%.1f".format(it)}% vs alvo") }
                            analysis.paceDeltaPct?.let { Text("Ritmo: ${if (it > 0) "mais lento" else "mais rápido"} ${"%.1f".format(kotlin.math.abs(it))}% vs referência") }
                            analysis.heartRate?.let { Text("FC média registada: ${it.toInt()} bpm") }
                        } }
                    }
                    OutlinedButton(onClick = { vm.importExecutionFromHealthConnect(workout) }) {
                        Text("Importar execução do Health Connect")
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    vm.saveWorkoutExecution(
                        workout.id,
                        distance.replace(',', '.').toDoubleOrNull()?.times(1000.0),
                        duration.replace(',', '.').toDoubleOrNull()?.times(60.0)?.toLong(),
                        pace.replace(',', '.').toDoubleOrNull()?.times(60.0),
                        hr.replace(',', '.').toDoubleOrNull(),
                        rpe.toIntOrNull(), notes
                    )
                    onClose()
                }) { Text("Guardar execução") }
            },
            dismissButton = { TextButton(onClick = onClose) { Text("Fechar") } }
        )
    }

    private fun paceText(seconds: Double?): String = seconds?.let { "%d:%02d".format((it / 60).toInt(), (it % 60).toInt()) } ?: "—"

    private fun WorkoutType.executionBlock(): String = when (this) {
        WorkoutType.EASY -> "2. Bloco principal — corrida contínua confortável, conversa possível, sem perseguir ritmo."
        WorkoutType.LONG_RUN -> "2. Bloco principal — corrida longa estável; começa conservador e mantém esforço controlado."
        WorkoutType.INTERVALS -> "2. Bloco principal — repetições rápidas conforme o plano, com recuperação completa o suficiente para manter técnica."
        WorkoutType.TEMPO -> "2. Bloco principal — bloco contínuo em esforço controlado/limiar, forte mas sustentável."
        WorkoutType.HILLS -> "2. Bloco principal — subidas fortes com postura alta e descidas fáceis para recuperar."
        WorkoutType.PROGRESSION -> "2. Bloco principal — começa fácil e aumenta gradualmente o esforço sem sprint final obrigatório."
        WorkoutType.RECOVERY -> "2. Bloco principal — corrida muito fácil; prioridade absoluta à recuperação."
        WorkoutType.REST -> "2. Bloco principal — descanso. Não transformar o dia em treino duro."
        WorkoutType.RACE -> "2. Bloco principal — prova. Executa a estratégia definida pelo treinador e evita sair acima do esforço-alvo."
    }

    private fun WorkoutType.recoveryBlock(): String = when (this) {
        WorkoutType.INTERVALS, WorkoutType.HILLS -> "1–3 min muito fácil entre repetições, conforme o plano."
        WorkoutType.TEMPO -> "5 min fácil antes de retomar o ritmo normal."
        else -> "corrida fácil até normalizar a respiração."
    }

    @Composable private fun ReportList(reports: List<com.runwise.app.report.ReportEngine.Summary>) { LazyColumn { items(reports) { r ->
        Card(Modifier.fillMaxWidth().padding(bottom=8.dp)) { Column(Modifier.padding(12.dp)) {
            Text(r.label, style=MaterialTheme.typography.titleMedium)
            Text("${r.runs} corridas • %.1f km • ${r.officialRaces} provas".format(r.km))
            Text("Ritmo médio: ${r.avgPaceSecKm?.let { "%.1f min/km".format(it/60.0) } ?: "—"}")
        } }
    } } }
    @Composable private fun SyncCenter(conflicts: List<SyncOperationEntity>, pendingSync: Int, conflictCount: Int, lastSync: Long, vm: MainViewModel) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Central de sincronização", style = MaterialTheme.typography.titleLarge)
            Text("Conflitos ficam aqui até escolheres qual versão manter.")
            Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp)) {
                Text("Estado", style = MaterialTheme.typography.titleMedium)
                Text("Pendentes: $pendingSync • Conflitos: $conflictCount")
                Text(if (lastSync > 0) "Última sincronização: ${java.time.Instant.ofEpochMilli(lastSync).atZone(java.time.ZoneId.systemDefault()).toLocalDateTime().toString().replace('T', ' ')}" else "Ainda não houve sincronização cloud concluída.")
            } }
            if (conflicts.isEmpty()) {
                Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp)) {
                    Text("Tudo sincronizado", style = MaterialTheme.typography.titleMedium)
                    Text("Não existem conflitos pendentes.")
                } }
            } else {
                conflicts.forEach { c ->
                    Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("${c.entityType} • ${c.entityId}", style = MaterialTheme.typography.titleMedium)
                        Text(c.lastError ?: "O servidor tem uma versão diferente deste registo.")
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { vm.acceptRemoteConflict(c) }) { Text("Aceitar cloud") }
                            OutlinedButton(onClick = { vm.keepLocalConflict(c) }) { Text("Manter local") }
                        }
                    } }
                }
            }
        }
    }

    @Composable private fun VideoLibrary() {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Técnicas de corrida", style = MaterialTheme.typography.titleLarge)
            RunWiseContent.videos.forEach { video ->
                Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp)) {
                    Text(video.title, style = MaterialTheme.typography.titleMedium)
                    Text(video.summary)
                    TextButton(onClick = {
                        val uri = Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(video.search))
                        startActivity(Intent(Intent.ACTION_VIEW, uri))
                    }) { Text("Ver vídeos") }
                } }
            }
        }
    }

}
