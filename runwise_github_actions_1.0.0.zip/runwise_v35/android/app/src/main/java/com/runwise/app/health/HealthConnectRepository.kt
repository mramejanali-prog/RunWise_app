package com.runwise.app.health

import android.content.Context
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.records.*
import androidx.health.connect.client.request.ReadRecordsRequest
import androidx.health.connect.client.time.TimeRangeFilter
import com.runwise.app.data.*
import java.time.Duration
import java.time.Instant

class HealthConnectRepository(private val context: Context) {
    private val client = HealthConnectClient.getOrCreate(context)

    val permissions = setOf(
        HealthPermission.getReadPermission(ExerciseSessionRecord::class),
        HealthPermission.getReadPermission(DistanceRecord::class),
        HealthPermission.getReadPermission(HeartRateRecord::class),
        HealthPermission.getReadPermission(SpeedRecord::class),
        HealthPermission.getReadPermission(ElevationGainedRecord::class)
    )

    suspend fun grantedPermissions() = client.permissionController.getGrantedPermissions()

    suspend fun readRuns(from: Instant, to: Instant): List<ActivityEntity> =
        readRunMetrics(from, to).map { it.toActivity() }

    data class RunMetrics(
        val externalId: String,
        val start: Instant,
        val end: Instant,
        val distanceMeters: Double,
        val avgHeartRate: Double?,
        val avgSpeedMetersPerSecond: Double?,
        val elevationGainMeters: Double?,
        val title: String?
    ) {
        val durationSeconds: Long get() = Duration.between(start, end).seconds
        val avgPaceSecondsPerKm: Double? get() =
            if (distanceMeters > 0 && durationSeconds > 0) durationSeconds / (distanceMeters / 1000.0) else null

        fun toActivity() = ActivityEntity(
            id = "healthconnect:$externalId",
            source = "HEALTH_CONNECT",
            externalId = externalId,
            kind = ActivityKind.TRAINING,
            raceId = null,
            startedAtEpochMs = start.toEpochMilli(),
            durationSeconds = durationSeconds,
            distanceMeters = distanceMeters,
            avgHeartRate = avgHeartRate,
            elevationGainMeters = elevationGainMeters,
            calories = null,
            avgPaceSecondsPerKm = avgPaceSecondsPerKm,
            title = title
        )
    }

    suspend fun findNearestRunningSession(target: Instant, windowHours: Long = 6): RunMetrics? {
        val from = target.minusSeconds(windowHours * 3600)
        val to = target.plusSeconds(windowHours * 3600)
        return readRunMetrics(from, to)
            .minByOrNull { kotlin.math.abs(Duration.between(target, it.start).seconds) }
    }

    private suspend fun readRunMetrics(from: Instant, to: Instant): List<RunMetrics> {
        val sessions = client.readRecords(
            ReadRecordsRequest(ExerciseSessionRecord::class, TimeRangeFilter.between(from, to))
        ).records.filter { it.exerciseType == ExerciseSessionRecord.EXERCISE_TYPE_RUNNING }

        return sessions.map { session ->
            val range = TimeRangeFilter.between(session.startTime, session.endTime)
            val distance = client.readRecords(ReadRecordsRequest(DistanceRecord::class, range)).records.sumOf { it.distance.inMeters }
            val heartSamples = client.readRecords(ReadRecordsRequest(HeartRateRecord::class, range)).records
                .flatMap { it.samples }.map { it.beatsPerMinute.toDouble() }
            val speedSamples = client.readRecords(ReadRecordsRequest(SpeedRecord::class, range)).records
                .flatMap { it.samples }.map { it.speed.inMetersPerSecond }
            val elevation = client.readRecords(ReadRecordsRequest(ElevationGainedRecord::class, range)).records
                .sumOf { it.elevation.inMeters }

            RunMetrics(
                externalId = session.metadata.id,
                start = session.startTime,
                end = session.endTime,
                distanceMeters = distance,
                avgHeartRate = heartSamples.takeIf { it.isNotEmpty() }?.average(),
                avgSpeedMetersPerSecond = speedSamples.takeIf { it.isNotEmpty() }?.average(),
                elevationGainMeters = elevation.takeIf { it > 0.0 },
                title = session.title
            )
        }
    }
}
