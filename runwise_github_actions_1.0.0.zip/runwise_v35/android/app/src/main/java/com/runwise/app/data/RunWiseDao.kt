package com.runwise.app.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface RunWiseDao {
    @Query("SELECT * FROM activities ORDER BY startedAtEpochMs DESC") fun activities(): Flow<List<ActivityEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertActivities(items: List<ActivityEntity>)
    @Query("SELECT * FROM races ORDER BY dateEpochMs ASC") fun races(): Flow<List<RaceEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertRaces(items: List<RaceEntity>)
    @Query("SELECT * FROM goals ORDER BY deadlineEpochMs ASC") fun goals(): Flow<List<GoalEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertGoal(goal: GoalEntity)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertGoalList(goals: List<GoalEntity>)
    @Query("SELECT * FROM planned_workouts ORDER BY dateEpochMs ASC") fun plannedWorkouts(): Flow<List<PlannedWorkoutEntity>>
    @Query("SELECT * FROM workout_executions") fun workoutExecutions(): Flow<List<WorkoutExecutionEntity>>
    @Query("SELECT * FROM workout_executions WHERE workoutId = :workoutId LIMIT 1") suspend fun workoutExecution(workoutId: String): WorkoutExecutionEntity?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertWorkoutExecution(item: WorkoutExecutionEntity)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertPlannedWorkouts(items: List<PlannedWorkoutEntity>)
    @Query("UPDATE planned_workouts SET completed = :completed WHERE id = :id") suspend fun setWorkoutCompleted(id: String, completed: Boolean)
    @Query("UPDATE planned_workouts SET skipped = :skipped WHERE id = :id") suspend fun setWorkoutSkipped(id: String, skipped: Boolean)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertCalendarSync(item: CalendarSyncEntity)
    @Query("SELECT * FROM calendar_sync WHERE workoutId = :workoutId LIMIT 1") suspend fun calendarSync(workoutId: String): CalendarSyncEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun enqueueSyncOperation(item: SyncOperationEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun enqueueSyncOperations(items: List<SyncOperationEntity>)

    @Query("SELECT * FROM sync_queue WHERE status = 'PENDING' ORDER BY createdAtEpochMs ASC")
    suspend fun syncQueue(): List<SyncOperationEntity>

    @Query("SELECT * FROM sync_queue WHERE status = 'CONFLICT' ORDER BY createdAtEpochMs ASC")
    fun conflicts(): Flow<List<SyncOperationEntity>>

    @Query("SELECT COUNT(*) FROM sync_queue WHERE status = 'PENDING'")
    fun pendingSyncCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM sync_queue WHERE status = 'CONFLICT'")
    fun conflictCount(): Flow<Int>

    @Query("DELETE FROM sync_queue WHERE operationKey IN (:keys)")
    suspend fun deleteSyncOperations(keys: List<String>)

    @Query("UPDATE sync_queue SET attemptCount = attemptCount + 1, lastError = :error WHERE operationKey IN (:keys)")
    suspend fun markSyncAttempt(keys: List<String>, error: String?)

    @Query("UPDATE sync_queue SET status = 'CONFLICT', lastError = :error WHERE operationKey IN (:keys)")
    suspend fun markSyncConflicts(keys: List<String>, error: String?)
}
