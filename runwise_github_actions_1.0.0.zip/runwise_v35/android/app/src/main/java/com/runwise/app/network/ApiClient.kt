package com.runwise.app.network

import android.content.Context
import com.runwise.app.BuildConfig
import com.runwise.app.security.SecureSessionStore
import com.runwise.app.data.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.time.Instant

class SessionExpiredException : IllegalStateException("Sessão expirada. Inicia sessão novamente.")

class ApiClient(context: Context) {
    private val appContext = context.applicationContext
    private val prefs = appContext.getSharedPreferences("runwise_auth", Context.MODE_PRIVATE)
    private val secureSession = SecureSessionStore(appContext).also { it.migrateLegacy() }
    private val baseUrl: String
        get() = prefs.getString("base_url", null)?.trimEnd('/') ?: BuildConfig.RUNWISE_API_BASE_URL.trimEnd('/').ifBlank { if (BuildConfig.DEBUG) "http://10.0.2.2:8000" else "" }

    data class Session(val token: String, val userId: String, val email: String)
    data class SyncResult(val pushed: Int, val pulled: List<ActivityEntity>, val conflicts: List<String> = emptyList())
    data class GoalSyncResult(val pushed: Int, val pulled: List<GoalEntity>, val conflicts: List<String> = emptyList())
    data class RaceSyncResult(val pushed: Int, val pulled: List<RaceEntity>, val conflicts: List<String> = emptyList())
    data class PlannedWorkoutSyncResult(val pushed: Int, val pulled: List<PlannedWorkoutEntity>, val conflicts: List<String> = emptyList())
    private fun cursorKey(kind: String) = "sync_cursor_$kind"
    private fun cursor(kind: String): String? = prefs.getString(cursorKey(kind), null)
    private fun saveCursor(kind: String, value: String?) { if (!value.isNullOrBlank()) prefs.edit().putString(cursorKey(kind), value).apply() }
    private fun maxUpdatedAt(json: JSONArray): String? { var max: String? = null; for (i in 0 until json.length()) { val v=json.getJSONObject(i).optString("updated_at").ifBlank{null}; if (v != null && (max == null || v > max!!)) max=v }; return max }
    private fun pathWithSince(path: String, kind: String): String = cursor(kind)?.let { "$path?since=${java.net.URLEncoder.encode(it, "UTF-8")}" } ?: path
    private fun pathWithBaseSince(path: String, kind: String): String = cursor(kind)?.let { "$path?base_since=${java.net.URLEncoder.encode(it, "UTF-8")}" } ?: path
    private fun clearCursors() = prefs.edit().remove("sync_cursor_activities").remove("sync_cursor_goals").remove("sync_cursor_races").remove("sync_cursor_planned_workouts").apply()

    fun session(): Session? = secureSession.get("token")?.let {
        Session(it, secureSession.get("user_id") ?: "", secureSession.get("email") ?: "")
    }
    fun baseUrl(): String = baseUrl
    fun setBaseUrl(url: String) {
        val normalized = url.trim().trimEnd('/')
        require(normalized.isNotBlank()) { "URL do servidor obrigatória" }
        require(normalized.startsWith("https://") || (BuildConfig.DEBUG && normalized == "http://10.0.2.2:8000")) {
            "Em release, o servidor deve usar HTTPS"
        }
        prefs.edit().putString("base_url", normalized).apply()
    }
    fun register(email: String, password: String): Session = auth("/v1/auth/register", email, password)
    fun login(email: String, password: String): Session = auth("/v1/auth/login", email, password)
    fun logout() { clearCursors(); secureSession.clearSession() }

    private fun auth(path: String, email: String, password: String): Session {
        val json = request("POST", path, JSONObject().put("email", email).put("password", password).toString(), false)
        val user = json.getJSONObject("user")
        return Session(json.getString("access_token"), user.getString("id"), user.getString("email")).also {
            clearCursors()
            secureSession.put("token", it.token); secureSession.put("user_id", it.userId); secureSession.put("email", it.email)
        }
    }


    fun syncGoals(items: List<GoalEntity>): GoalSyncResult {
        val payload = JSONArray().apply { items.forEach { g ->
            put(JSONObject().apply {
                put("id", g.id); put("name", g.name); put("target_value", g.targetValue); put("current_value", g.currentValue); put("unit", g.unit)
                put("deadline", g.deadlineEpochMs?.let { Instant.ofEpochMilli(it).toString() } ?: JSONObject.NULL)
            })
        }}
        val pushed = request("POST", pathWithBaseSince("/v1/sync/goals", "goals"), payload.toString())
        val pulled = request("GET", pathWithSince("/v1/sync/goals", "goals")).getJSONArray("items")
        val result = ArrayList<GoalEntity>(pulled.length())
        saveCursor("goals", maxUpdatedAt(pulled))
        for (i in 0 until pulled.length()) { val j=pulled.getJSONObject(i); result.add(GoalEntity(j.getString("id"),j.getString("name"),j.getDouble("target_value"),j.getDouble("current_value"),j.getString("unit"),if(j.isNull("deadline")) null else Instant.parse(j.getString("deadline")).toEpochMilli())) }
        return GoalSyncResult(pushed.optInt("accepted", items.size), result, jsonConflicts(pushed))
    }

    fun syncRaces(items: List<RaceEntity>): RaceSyncResult {
        val payload = JSONArray().apply { items.forEach { r ->
            put(JSONObject().apply { put("id",r.id); put("provider",r.provider); put("external_id",r.externalId ?: JSONObject.NULL); put("name",r.name); put("date",Instant.ofEpochMilli(r.dateEpochMs).toString()); put("distance_meters",r.distanceMeters ?: JSONObject.NULL); put("location",r.location ?: JSONObject.NULL); put("registration_status",r.registrationStatus) })
        }}
        val pushed = request("POST", pathWithBaseSince("/v1/sync/races", "races"), payload.toString())
        val pulled = request("GET", pathWithSince("/v1/sync/races", "races")).getJSONArray("items")
        val result=ArrayList<RaceEntity>(pulled.length())
        saveCursor("races", maxUpdatedAt(pulled))
        for(i in 0 until pulled.length()){ val j=pulled.getJSONObject(i); result.add(RaceEntity(j.getString("id"),j.getString("provider"),j.optString("external_id").ifBlank{null},j.getString("name"),Instant.parse(j.getString("date")).toEpochMilli(),if(j.isNull("distance_meters"))null else j.getDouble("distance_meters"),j.optString("location").ifBlank{null},j.optString("registration_status","UNKNOWN"))) }
        return RaceSyncResult(pushed.optInt("accepted", items.size), result, jsonConflicts(pushed))
    }

    fun syncPlannedWorkouts(items: List<PlannedWorkoutEntity>): PlannedWorkoutSyncResult {
        val payload = JSONArray().apply { items.forEach { w ->
            put(JSONObject().apply {
                put("id", w.id); put("date", Instant.ofEpochMilli(w.dateEpochMs).toString()); put("type", w.type.name)
                put("title", w.title); put("description", w.description)
                put("target_distance_meters", w.targetDistanceMeters ?: JSONObject.NULL); put("target_duration_seconds", w.targetDurationSeconds ?: JSONObject.NULL)
                put("target_pace_min_seconds_per_km", w.targetPaceMinSecondsPerKm ?: JSONObject.NULL); put("target_pace_max_seconds_per_km", w.targetPaceMaxSecondsPerKm ?: JSONObject.NULL)
                put("completed", w.completed); put("skipped", w.skipped); put("generated_reason", w.generatedReason ?: JSONObject.NULL)
            })
        }}
        val pushed = request("POST", pathWithBaseSince("/v1/sync/planned-workouts", "planned_workouts"), payload.toString())
        val pulled = request("GET", pathWithSince("/v1/sync/planned-workouts", "planned_workouts")).getJSONArray("items")
        val result = ArrayList<PlannedWorkoutEntity>(pulled.length())
        saveCursor("planned_workouts", maxUpdatedAt(pulled))
        for (i in 0 until pulled.length()) {
            val j=pulled.getJSONObject(i)
            result.add(PlannedWorkoutEntity(
                id=j.getString("id"), dateEpochMs=Instant.parse(j.getString("date")).toEpochMilli(),
                type=runCatching { WorkoutType.valueOf(j.getString("type")) }.getOrDefault(WorkoutType.EASY),
                title=j.getString("title"), description=j.optString("description",""),
                targetDistanceMeters=if(j.isNull("target_distance_meters")) null else j.getDouble("target_distance_meters"),
                targetDurationSeconds=if(j.isNull("target_duration_seconds")) null else j.getLong("target_duration_seconds"),
                targetPaceMinSecondsPerKm=if(j.isNull("target_pace_min_seconds_per_km")) null else j.getDouble("target_pace_min_seconds_per_km"),
                targetPaceMaxSecondsPerKm=if(j.isNull("target_pace_max_seconds_per_km")) null else j.getDouble("target_pace_max_seconds_per_km"),
                completed=j.optBoolean("completed",false), skipped=j.optBoolean("skipped",false), generatedReason=j.optString("generated_reason").ifBlank{null}
            ))
        }
        return PlannedWorkoutSyncResult(pushed.optInt("accepted", items.size), result, jsonConflicts(pushed))
    }

    private fun currentPath(kind: String): String = when (kind) {
        "activities" -> "/v1/sync/activities"
        "goals" -> "/v1/sync/goals"
        "races" -> "/v1/sync/races"
        "planned_workouts" -> "/v1/sync/planned-workouts"
        else -> error("Tipo de entidade inválido")
    }

    private fun currentObject(kind: String, id: String): JSONObject? {
        val raw = request("GET", currentPath(kind))
        val arr = if (kind == "activities") raw else raw.getJSONArray("items")
        for (i in 0 until arr.length()) {
            val j = arr.getJSONObject(i)
            if (j.optString("id") == id) return j
        }
        return null
    }

    fun fetchCurrent(kind: String, id: String): Any? {
        val j = currentObject(kind, id) ?: return null
        return when (kind) {
            "activities" -> ActivityEntity(j.getString("id"), j.getString("source"), j.optString("external_id").ifBlank { null }, runCatching { ActivityKind.valueOf(j.optString("kind", "TRAINING")) }.getOrDefault(ActivityKind.TRAINING), j.optString("race_id").ifBlank { null }, Instant.parse(j.getString("started_at")).toEpochMilli(), j.getLong("duration_seconds"), j.getDouble("distance_meters"), if (j.isNull("avg_heart_rate")) null else j.getDouble("avg_heart_rate"), if (j.isNull("elevation_gain_meters")) null else j.getDouble("elevation_gain_meters"), null, if (j.isNull("avg_pace_seconds_per_km")) null else j.getDouble("avg_pace_seconds_per_km"), null)
            "goals" -> GoalEntity(j.getString("id"), j.getString("name"), j.getDouble("target_value"), j.getDouble("current_value"), j.getString("unit"), if (j.isNull("deadline")) null else Instant.parse(j.getString("deadline")).toEpochMilli())
            "races" -> RaceEntity(j.getString("id"), j.getString("provider"), j.optString("external_id").ifBlank { null }, j.getString("name"), Instant.parse(j.getString("date")).toEpochMilli(), if (j.isNull("distance_meters")) null else j.getDouble("distance_meters"), j.optString("location").ifBlank { null }, j.optString("registration_status", "UNKNOWN"))
            else -> PlannedWorkoutEntity(j.getString("id"), Instant.parse(j.getString("date")).toEpochMilli(), runCatching { WorkoutType.valueOf(j.getString("type")) }.getOrDefault(WorkoutType.EASY), j.getString("title"), j.optString("description", ""), if (j.isNull("target_distance_meters")) null else j.getDouble("target_distance_meters"), if (j.isNull("target_duration_seconds")) null else j.getLong("target_duration_seconds"), if (j.isNull("target_pace_min_seconds_per_km")) null else j.getDouble("target_pace_min_seconds_per_km"), if (j.isNull("target_pace_max_seconds_per_km")) null else j.getDouble("target_pace_max_seconds_per_km"), j.optBoolean("completed"), j.optBoolean("skipped"), j.optString("generated_reason").ifBlank { null })
        }
    }

    private fun entityJson(entity: Any): JSONObject = when (entity) {
        is ActivityEntity -> JSONObject().apply { put("id",entity.id); put("source",entity.source); put("external_id",entity.externalId ?: JSONObject.NULL); put("kind",entity.kind.name); put("race_id",entity.raceId ?: JSONObject.NULL); put("started_at",Instant.ofEpochMilli(entity.startedAtEpochMs).toString()); put("duration_seconds",entity.durationSeconds); put("distance_meters",entity.distanceMeters); put("avg_heart_rate",entity.avgHeartRate ?: JSONObject.NULL); put("elevation_gain_meters",entity.elevationGainMeters ?: JSONObject.NULL); put("avg_pace_seconds_per_km",entity.avgPaceSecondsPerKm ?: JSONObject.NULL) }
        is GoalEntity -> JSONObject().apply { put("id",entity.id); put("name",entity.name); put("target_value",entity.targetValue); put("current_value",entity.currentValue); put("unit",entity.unit); put("deadline",entity.deadlineEpochMs?.let { Instant.ofEpochMilli(it).toString() } ?: JSONObject.NULL) }
        is RaceEntity -> JSONObject().apply { put("id",entity.id); put("provider",entity.provider); put("external_id",entity.externalId ?: JSONObject.NULL); put("name",entity.name); put("date",Instant.ofEpochMilli(entity.dateEpochMs).toString()); put("distance_meters",entity.distanceMeters ?: JSONObject.NULL); put("location",entity.location ?: JSONObject.NULL); put("registration_status",entity.registrationStatus) }
        is PlannedWorkoutEntity -> JSONObject().apply { put("id",entity.id); put("date",Instant.ofEpochMilli(entity.dateEpochMs).toString()); put("type",entity.type.name); put("title",entity.title); put("description",entity.description); put("target_distance_meters",entity.targetDistanceMeters ?: JSONObject.NULL); put("target_duration_seconds",entity.targetDurationSeconds ?: JSONObject.NULL); put("target_pace_min_seconds_per_km",entity.targetPaceMinSecondsPerKm ?: JSONObject.NULL); put("target_pace_max_seconds_per_km",entity.targetPaceMaxSecondsPerKm ?: JSONObject.NULL); put("completed",entity.completed); put("skipped",entity.skipped); put("generated_reason",entity.generatedReason ?: JSONObject.NULL) }
        else -> error("Tipo de entidade inválido")
    }

    fun forceLocal(kind: String, entity: Any) {
        val id = when (entity) { is ActivityEntity -> entity.id; is GoalEntity -> entity.id; is RaceEntity -> entity.id; is PlannedWorkoutEntity -> entity.id; else -> error("Tipo inválido") }
        val remote = currentObject(kind, id) ?: throw IllegalStateException("Registo remoto não encontrado")
        val updated = remote.optString("updated_at").ifBlank { throw IllegalStateException("Versão remota indisponível") }
        val url = currentPath(kind) + "?base_since=" + java.net.URLEncoder.encode(updated, "UTF-8")
        val result = request("POST", url, JSONArray().put(entityJson(entity)).toString())
        if (result.optInt("accepted", 0) != 1) throw IllegalStateException("O servidor não aceitou a versão local")
    }

    fun syncActivities(items: List<ActivityEntity>): SyncResult {
        val payload = JSONArray().apply { items.forEach { a ->
            put(JSONObject().apply {
                put("id", a.id); put("source", a.source); put("external_id", a.externalId ?: JSONObject.NULL)
                put("kind", a.kind.name); put("race_id", a.raceId ?: JSONObject.NULL)
                put("started_at", Instant.ofEpochMilli(a.startedAtEpochMs).toString())
                put("duration_seconds", a.durationSeconds); put("distance_meters", a.distanceMeters)
                put("avg_heart_rate", a.avgHeartRate ?: JSONObject.NULL); put("elevation_gain_meters", a.elevationGainMeters ?: JSONObject.NULL)
                put("avg_pace_seconds_per_km", a.avgPaceSecondsPerKm ?: JSONObject.NULL)
            })
        }}
        val pushed = request("POST", pathWithBaseSince("/v1/sync/activities", "activities"), payload.toString())
        val pulled = request("GET", pathWithSince("/v1/sync/activities", "activities"))
        val rows = pulled.getJSONArray("items")
        saveCursor("activities", maxUpdatedAt(rows))
        val result = ArrayList<ActivityEntity>(rows.length())
        for (i in 0 until rows.length()) {
            val j = rows.getJSONObject(i)
            result.add(ActivityEntity(
                id = j.getString("id"), source = j.getString("source"), externalId = j.optString("external_id").ifBlank { null },
                kind = runCatching { ActivityKind.valueOf(j.optString("kind", "TRAINING")) }.getOrDefault(ActivityKind.TRAINING),
                raceId = j.optString("race_id").ifBlank { null }, startedAtEpochMs = Instant.parse(j.getString("started_at")).toEpochMilli(),
                durationSeconds = j.getLong("duration_seconds"), distanceMeters = j.getDouble("distance_meters"),
                avgHeartRate = if (j.isNull("avg_heart_rate")) null else j.getDouble("avg_heart_rate"),
                elevationGainMeters = if (j.isNull("elevation_gain_meters")) null else j.getDouble("elevation_gain_meters"),
                calories = null, avgPaceSecondsPerKm = if (j.isNull("avg_pace_seconds_per_km")) null else j.getDouble("avg_pace_seconds_per_km"), title = null
            ))
        }
        return SyncResult(pushed.optInt("accepted", items.size), result, jsonConflicts(pushed))
    }

    private fun jsonConflicts(json: JSONObject): List<String> {
        val a = json.optJSONArray("conflicts") ?: return emptyList()
        return List(a.length()) { i -> a.getString(i) }
    }

    private fun request(method: String, path: String, body: String? = null, authenticated: Boolean = true): JSONObject {
        require(baseUrl.isNotBlank()) { "Servidor não configurado. Define a URL da API." }
        val conn = (URL(baseUrl + path).openConnection() as HttpURLConnection).apply {
            requestMethod = method; connectTimeout = 10000; readTimeout = 15000
            setRequestProperty("Content-Type", "application/json")
            if (authenticated) session()?.token?.let { setRequestProperty("Authorization", "Bearer $it") }
            if (body != null) doOutput = true
        }
        body?.let { conn.outputStream.use { out -> out.write(it.toByteArray(Charsets.UTF_8)) } }
        val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
        val text = stream.bufferedReader().use { it.readText() }
        if (conn.responseCode == 401 && authenticated) { secureSession.clearSession(); clearCursors(); throw SessionExpiredException() }
        if (conn.responseCode !in 200..299) error("API ${conn.responseCode}: $text")
        return if (text.trimStart().startsWith("[")) JSONObject().put("items", JSONArray(text)) else JSONObject(text)
    }
}
