package com.runwise.app.content

import java.time.LocalDate

object RunWiseContent {
    data class VideoTechnique(val title: String, val summary: String, val search: String)

    private val motivations = listOf(
        "Hoje não precisas de correr perfeito. Precisas de começar.",
        "Consistência vence a inspiração quando a meta é de longo prazo.",
        "Corre com controlo hoje para teres pernas amanhã.",
        "Cada treino é uma conversa entre o atleta de hoje e o atleta que queres ser.",
        "O ritmo certo é aquele que te permite repetir o esforço com qualidade.",
        "Não compenses um treino perdido exagerando no seguinte. Volta ao plano.",
        "A recuperação também faz parte do treino."
    )

    val videos = listOf(
        VideoTechnique("Técnica de corrida", "Postura, cadência, apoio e economia de movimento.", "running technique posture cadence foot strike"),
        VideoTechnique("Aquecimento", "Rotina dinâmica antes de treinos fáceis, longos e de qualidade.", "running warm up drills dynamic"),
        VideoTechnique("Intervalos", "Como controlar repetições rápidas sem começar acima do alvo.", "running interval workout pacing"),
        VideoTechnique("Subidas", "Inclinação, passada e esforço percebido para correr em subida.", "hill running technique"),
        VideoTechnique("Descida", "Controlo da passada e estabilidade sem travar excessivamente.", "downhill running technique"),
        VideoTechnique("Longão", "Como gerir ritmo, hidratação e progressão durante corridas longas.", "long run pacing hydration technique"),
        VideoTechnique("Recuperação", "Sinais de fadiga e estratégias simples entre sessões.", "running recovery easy run mobility")
    )

    fun dailyMotivation(date: LocalDate = LocalDate.now()): String =
        motivations[Math.floorMod(date.toEpochDay().toInt(), motivations.size)]
}
