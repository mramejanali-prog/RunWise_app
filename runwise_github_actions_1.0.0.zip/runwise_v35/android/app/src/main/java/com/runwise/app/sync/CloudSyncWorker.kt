package com.runwise.app.sync

import android.content.Context
import androidx.room.Room
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.runwise.app.data.RunWiseDatabase
import com.runwise.app.network.ApiClient
import com.runwise.app.network.SessionExpiredException
import kotlinx.coroutines.flow.first

class CloudSyncWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        val api = ApiClient(applicationContext)
        if (api.session() == null) return Result.success()
        val db = Room.databaseBuilder(applicationContext, RunWiseDatabase::class.java, "runwise.db")
            .addMigrations(RunWiseDatabase.MIGRATION_3_4)
            .fallbackToDestructiveMigrationFrom(1, 2)
            .build()
        val dao = db.dao()
        val queue = dao.syncQueue()
        val keys = queue.map { it.operationKey }
        fun key(type: String, id: String) = "$type:$id"
        suspend fun resolve(type: String, conflicts: List<String>) {
            val conflictKeys = conflicts.map { key(type, it) }.filter { it in keys }
            if (conflictKeys.isNotEmpty()) dao.markSyncConflicts(conflictKeys, "Conflito de versão no servidor; alteração local mantida para revisão.")
        }
        return try {
            val activities = dao.activities().first()
            val activityIds = queue.filter { it.entityType == "activities" && it.status == "PENDING" }.map { it.entityId }.toSet()
            val activityResult = api.syncActivities(activities.filter { it.id in activityIds })
            resolve("activities", activityResult.conflicts)
            val conflictActivities = activityResult.conflicts.toSet()
            dao.upsertActivities(activityResult.pulled.filterNot { it.id in conflictActivities })

            val goals = dao.goals().first()
            val goalIds = queue.filter { it.entityType == "goals" && it.status == "PENDING" }.map { it.entityId }.toSet()
            val goalResult = api.syncGoals(goals.filter { it.id in goalIds })
            resolve("goals", goalResult.conflicts)
            val conflictGoals = goalResult.conflicts.toSet()
            dao.upsertGoalList(goalResult.pulled.filterNot { it.id in conflictGoals })

            val races = dao.races().first()
            val raceIds = queue.filter { it.entityType == "races" && it.status == "PENDING" }.map { it.entityId }.toSet()
            val raceResult = api.syncRaces(races.filter { it.id in raceIds })
            resolve("races", raceResult.conflicts)
            dao.upsertRaces(raceResult.pulled)

            val planned = dao.plannedWorkouts().first()
            val plannedIds = queue.filter { it.entityType == "planned_workouts" && it.status == "PENDING" }.map { it.entityId }.toSet()
            val plannedResult = api.syncPlannedWorkouts(planned.filter { it.id in plannedIds })
            resolve("planned_workouts", plannedResult.conflicts)
            val conflictPlanned = plannedResult.conflicts.toSet()
            dao.upsertPlannedWorkouts(plannedResult.pulled.filterNot { it.id in conflictPlanned })

            val conflictKeys = (
                activityResult.conflicts.map { key("activities", it) } +
                goalResult.conflicts.map { key("goals", it) } +
                raceResult.conflicts.map { key("races", it) } +
                plannedResult.conflicts.map { key("planned_workouts", it) }
            ).toSet()
            val resolvedKeys = keys.filterNot { it in conflictKeys }
            if (resolvedKeys.isNotEmpty()) dao.deleteSyncOperations(resolvedKeys)
            SyncStatusStore(applicationContext).markSuccess()
            db.close()
            Result.success()
        } catch (e: SessionExpiredException) {
            db.close()
            Result.success()
        } catch (e: Exception) {
            if (keys.isNotEmpty()) dao.markSyncAttempt(keys, e.message?.take(500))
            db.close()
            Result.retry()
        }
    }
}
