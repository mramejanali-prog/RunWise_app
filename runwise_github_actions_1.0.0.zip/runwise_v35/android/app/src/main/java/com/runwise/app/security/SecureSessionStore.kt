package com.runwise.app.security

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.nio.charset.StandardCharsets
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.spec.GCMParameterSpec

/** Android Keystore-backed storage for the authentication session. */
class SecureSessionStore(context: Context) {
    private val app = context.applicationContext
    private val prefs = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }

    fun get(name: String): String? = prefs.getString(name, null)?.let { decrypt(it) }

    fun put(name: String, value: String) {
        prefs.edit().putString(name, encrypt(value)).apply()
    }

    fun remove(name: String) { prefs.edit().remove(name).apply() }

    fun clearSession() {
        listOf("token", "user_id", "email").forEach(::remove)
    }

    /** One-time migration from the old plaintext runwise_auth preferences. */
    fun migrateLegacy() {
        val legacy = app.getSharedPreferences("runwise_auth", Context.MODE_PRIVATE)
        val editor = prefs.edit()
        listOf("token", "user_id", "email").forEach { key ->
            if (prefs.getString(key, null) == null) {
                legacy.getString(key, null)?.let { editor.putString(key, encrypt(it)) }
            }
        }
        editor.apply()
        legacy.edit().remove("token").remove("user_id").remove("email").apply()
    }

    private fun key(): javax.crypto.SecretKey {
        if (!keyStore.containsAlias(KEY_ALIAS)) {
            val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE)
            generator.init(KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            ).setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .build())
            generator.generateKey()
        }
        return (keyStore.getEntry(KEY_ALIAS, null) as KeyStore.SecretKeyEntry).secretKey
    }

    private fun encrypt(value: String): String {
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, key())
        val combined = cipher.iv + cipher.doFinal(value.toByteArray(StandardCharsets.UTF_8))
        return Base64.encodeToString(combined, Base64.NO_WRAP)
    }

    private fun decrypt(value: String): String? = runCatching {
        val bytes = Base64.decode(value, Base64.NO_WRAP)
        val iv = bytes.copyOfRange(0, 12)
        val payload = bytes.copyOfRange(12, bytes.size)
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, iv))
        String(cipher.doFinal(payload), StandardCharsets.UTF_8)
    }.getOrNull()

    companion object {
        private const val PREFS = "runwise_secure_session"
        private const val ANDROID_KEYSTORE = "AndroidKeyStore"
        private const val KEY_ALIAS = "runwise_session_key"
        private const val TRANSFORMATION = "AES/GCM/NoPadding"
    }
}
