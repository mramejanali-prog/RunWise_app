package com.runwise.app.calendar

import android.content.ContentResolver
import android.content.ContentValues
import android.provider.CalendarContract
import com.runwise.app.data.CalendarSyncEntity
import com.runwise.app.data.PlannedWorkoutEntity
import java.time.Instant
import java.time.ZoneId

class CalendarRepository(private val resolver: ContentResolver) {
    fun hasWritableCalendar(): Boolean = findCalendarId() != null

    fun exportWorkout(workout: PlannedWorkoutEntity): CalendarSyncEntity? {
        val calendarId = findCalendarId() ?: return null
        val zone = ZoneId.systemDefault()
        val start = Instant.ofEpochMilli(workout.dateEpochMs).atZone(zone)
            .withHour(6).withMinute(0).withSecond(0).withNano(0)
        val durationMinutes = workout.targetDurationSeconds?.div(60)?.coerceAtLeast(30) ?: 60
        val end = start.plusMinutes(durationMinutes)
        val values = ContentValues().apply {
            put(CalendarContract.Events.CALENDAR_ID, calendarId)
            put(CalendarContract.Events.TITLE, "RunWise • ${workout.title}")
            put(CalendarContract.Events.DESCRIPTION, description(workout))
            put(CalendarContract.Events.DTSTART, start.toInstant().toEpochMilli())
            put(CalendarContract.Events.DTEND, end.toInstant().toEpochMilli())
            put(CalendarContract.Events.EVENT_TIMEZONE, zone.id)
            put(CalendarContract.Events.STATUS, CalendarContract.Events.STATUS_CONFIRMED)
        }
        val uri = resolver.insert(CalendarContract.Events.CONTENT_URI, values) ?: return null
        val eventId = uri.lastPathSegment?.toLongOrNull() ?: return null
        return CalendarSyncEntity(workout.id, eventId, System.currentTimeMillis())
    }

    fun exportWeek(workouts: List<PlannedWorkoutEntity>): List<CalendarSyncEntity> =
        workouts.mapNotNull { exportWorkout(it) }

    private fun findCalendarId(): Long? {
        val projection = arrayOf(CalendarContract.Calendars._ID, CalendarContract.Calendars.CALENDAR_ACCESS_LEVEL, CalendarContract.Calendars.ACCOUNT_TYPE, CalendarContract.Calendars.VISIBLE)
        resolver.query(CalendarContract.Calendars.CONTENT_URI, projection, null, null, null)?.use { c ->
            val idIndex = c.getColumnIndex(CalendarContract.Calendars._ID)
            val accessIndex = c.getColumnIndex(CalendarContract.Calendars.CALENDAR_ACCESS_LEVEL)
            val typeIndex = c.getColumnIndex(CalendarContract.Calendars.ACCOUNT_TYPE)
            val visibleIndex = c.getColumnIndex(CalendarContract.Calendars.VISIBLE)
            var fallback: Long? = null
            while (c.moveToNext()) {
                val access = c.getInt(accessIndex)
                if (access < CalendarContract.Calendars.CAL_ACCESS_CONTRIBUTOR) continue
                if (visibleIndex >= 0 && c.getInt(visibleIndex) == 0) continue
                val id = c.getLong(idIndex)
                if (fallback == null) fallback = id
                val accountType = if (typeIndex >= 0) c.getString(typeIndex) else null
                if (accountType.equals("com.google", ignoreCase = true)) return id
            }
            return fallback
        }
        return null
    }

    private fun description(w: PlannedWorkoutEntity): String = buildString {
        append(w.description)
        w.targetDistanceMeters?.let { append("\nDistância alvo: %.1f km".format(it / 1000.0)) }
        if (w.targetPaceMinSecondsPerKm != null || w.targetPaceMaxSecondsPerKm != null) {
            append("\nRitmo alvo: ")
            w.targetPaceMinSecondsPerKm?.let { append("%.1f".format(it / 60.0)) }
            append("–")
            w.targetPaceMaxSecondsPerKm?.let { append("%.1f".format(it / 60.0)) }
            append(" min/km")
        }
        w.generatedReason?.let { append("\nMotivo: $it") }
    }
}
