package com.runwise.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class ActivityKind { TRAINING, OFFICIAL_RACE }
enum class WorkoutType { EASY, LONG_RUN, INTERVALS, TEMPO, HILLS, PROGRESSION, RECOVERY, REST, RACE }

@Entity(tableName = "activities")
data class ActivityEntity(
    @PrimaryKey val id: String,
    val source: String,
    val externalId: String?,
    val kind: ActivityKind,
    val raceId: String?,
    val startedAtEpochMs: Long,
    val durationSeconds: Long,
    val distanceMeters: Double,
    val avgHeartRate: Double?,
    val elevationGainMeters: Double?,
    val calories: Double?,
    val avgPaceSecondsPerKm: Double?,
    val title: String?
)

@Entity(tableName = "races")
data class RaceEntity(
    @PrimaryKey val id: String,
    val provider: String,
    val externalId: String?,
    val name: String,
    val dateEpochMs: Long,
    val distanceMeters: Double?,
    val location: String?,
    val registrationStatus: String = "UNKNOWN"
)

@Entity(tableName = "goals")
data class GoalEntity(
    @PrimaryKey val id: String,
    val name: String,
    val targetValue: Double,
    val currentValue: Double,
    val unit: String,
    val deadlineEpochMs: Long?
)

@Entity(tableName = "planned_workouts")
data class PlannedWorkoutEntity(
    @PrimaryKey val id: String,
    val dateEpochMs: Long,
    val type: WorkoutType,
    val title: String,
    val description: String,
    val targetDistanceMeters: Double?,
    val targetDurationSeconds: Long?,
    val targetPaceMinSecondsPerKm: Double?,
    val targetPaceMaxSecondsPerKm: Double?,
    val completed: Boolean = false,
    val skipped: Boolean = false,
    val generatedReason: String? = null
)


@Entity(tableName = "workout_executions")
data class WorkoutExecutionEntity(
    @PrimaryKey val workoutId: String,
    val completedAtEpochMs: Long,
    val actualDistanceMeters: Double?,
    val actualDurationSeconds: Long?,
    val actualAvgPaceSecondsPerKm: Double?,
    val actualAvgHeartRate: Double?,
    val perceivedEffort: Int?,
    val notes: String?
)

@Entity(tableName = "calendar_sync")
data class CalendarSyncEntity(
    @PrimaryKey val workoutId: String,
    val calendarEventId: Long,
    val syncedAtEpochMs: Long
)

@Entity(tableName = "sync_queue")
data class SyncOperationEntity(
    @PrimaryKey val operationKey: String,
    val entityType: String,
    val entityId: String,
    val operation: String = "UPSERT",
    val createdAtEpochMs: Long = System.currentTimeMillis(),
    val attemptCount: Int = 0,
    val lastError: String? = null,
    val status: String = "PENDING"
)
