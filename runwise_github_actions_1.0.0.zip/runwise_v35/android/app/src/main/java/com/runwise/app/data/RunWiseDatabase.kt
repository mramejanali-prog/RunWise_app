package com.runwise.app.data

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(entities = [ActivityEntity::class, RaceEntity::class, GoalEntity::class, PlannedWorkoutEntity::class, CalendarSyncEntity::class, SyncOperationEntity::class, WorkoutExecutionEntity::class], version = 5, exportSchema = false)
abstract class RunWiseDatabase : RoomDatabase() {
    abstract fun dao(): RunWiseDao

    companion object {
        val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS sync_queue (operationKey TEXT NOT NULL PRIMARY KEY, entityType TEXT NOT NULL, entityId TEXT NOT NULL, operation TEXT NOT NULL, createdAtEpochMs INTEGER NOT NULL, attemptCount INTEGER NOT NULL, lastError TEXT, status TEXT NOT NULL DEFAULT 'PENDING')")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_sync_queue_createdAtEpochMs ON sync_queue(createdAtEpochMs)")
            }
        }
        val MIGRATION_4_5 = object : Migration(4, 5) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS workout_executions (workoutId TEXT NOT NULL PRIMARY KEY, completedAtEpochMs INTEGER NOT NULL, actualDistanceMeters REAL, actualDurationSeconds INTEGER, actualAvgPaceSecondsPerKm REAL, actualAvgHeartRate REAL, perceivedEffort INTEGER, notes TEXT)")
            }
        }
    }
}
