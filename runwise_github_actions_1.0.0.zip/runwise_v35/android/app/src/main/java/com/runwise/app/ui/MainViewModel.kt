package com.runwise.app.ui

import android.app.Application
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import com.runwise.app.calendar.CalendarRepository
import com.runwise.app.content.RunWiseContent
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.Room
import androidx.work.Constraints
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.BackoffPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import com.runwise.app.coach.AdaptiveCoach
import com.runwise.app.data.*
import com.runwise.app.health.HealthConnectRepository
import com.runwise.app.report.ReportEngine
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.time.*
import java.time.temporal.ChronoUnit
import com.runwise.app.network.ApiClient
import com.runwise.app.sync.CloudSyncWorker
import com.runwise.app.sync.SyncStatusStore
import com.runwise.app.network.SessionExpiredException

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val db = Room.databaseBuilder(app, RunWiseDatabase::class.java, "runwise.db").addMigrations(RunWiseDatabase.MIGRATION_3_4, RunWiseDatabase.MIGRATION_4_5).fallbackToDestructiveMigrationFrom(1, 2).build()
    private val dao = db.dao()
    private val health = HealthConnectRepository(app)
    private val calendar = CalendarRepository(app.contentResolver)
    private val api = ApiClient(app)
    private val workManager = WorkManager.getInstance(app)
    private val syncStatus = SyncStatusStore(app)

    private fun markDirty(entityType: String, entityId: String) {
        viewModelScope.launch(Dispatchers.IO) {
            dao.enqueueSyncOperation(SyncOperationEntity(
                operationKey = "$entityType:$entityId",
                entityType = entityType,
                entityId = entityId
            ))
            val request = OneTimeWorkRequestBuilder<CloudSyncWorker>()
                .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, java.util.concurrent.TimeUnit.SECONDS)
                .build()
            workManager.enqueueUniqueWork("runwise-cloud-sync-now", ExistingWorkPolicy.KEEP, request)
        }
    }
    val dailyMotivation = MutableStateFlow(RunWiseContent.dailyMotivation())
    val loggedIn = MutableStateFlow(api.session() != null)
    val activities = dao.activities().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val races = dao.races().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val goals = dao.goals().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val planned = dao.plannedWorkouts().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val executions = dao.workoutExecutions().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val conflicts = dao.conflicts().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val pendingSyncCount = dao.pendingSyncCount().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)
    val conflictCount = dao.conflictCount().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)
    val lastSyncEpochMs = MutableStateFlow(syncStatus.lastSuccessEpochMs())
    val coachState = combine(activities, races) { a, r -> AdaptiveCoach.assess(a, r) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AdaptiveCoach.assess(emptyList(), emptyList()))
    val reports = activities.map { ReportEngine.allPeriods(it) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val message = MutableStateFlow("Liga o Health Connect para importar os teus treinos.")

    fun syncHealthConnect() = viewModelScope.launch {
        runCatching {
            val end = Instant.now(); val start = end.minus(365, ChronoUnit.DAYS)
            val imported = health.readRuns(start, end)
            dao.upsertActivities(imported)
            dao.enqueueSyncOperations(imported.map { SyncOperationEntity("activities:${it.id}", "activities", it.id) })
            message.value = "${imported.size} treinos sincronizados."
            generateCurrentPlan()
        }.onFailure { message.value = "Não foi possível sincronizar: ${it.message ?: "erro desconhecido"}" }
    }

    fun generateCurrentPlan() = viewModelScope.launch {
        val state = coachState.value
        val weekStart = LocalDate.now().with(java.time.DayOfWeek.MONDAY)
        val workouts = AdaptiveCoach.generateWeek(state, weekStart)
        dao.upsertPlannedWorkouts(workouts)
        dao.enqueueSyncOperations(workouts.map { SyncOperationEntity("planned_workouts:${it.id}", "planned_workouts", it.id) })
        message.value = "Plano adaptativo gerado: ${workouts.count { it.type != WorkoutType.REST && it.type != WorkoutType.RECOVERY }} sessões principais."
    }

    fun completeWorkout(id: String) = viewModelScope.launch {
        dao.setWorkoutCompleted(id, true)
        markDirty("planned_workouts", id)
    }
    fun skipWorkout(id: String) = viewModelScope.launch {
        dao.setWorkoutSkipped(id, true)
        markDirty("planned_workouts", id)
    }

    fun saveWorkoutExecution(workoutId: String, distanceMeters: Double?, durationSeconds: Long?, paceSecondsPerKm: Double?, avgHeartRate: Double?, perceivedEffort: Int?, notes: String?) = viewModelScope.launch(Dispatchers.IO) {
        val cleanRpe = perceivedEffort?.coerceIn(1, 10)
        dao.upsertWorkoutExecution(WorkoutExecutionEntity(workoutId, System.currentTimeMillis(), distanceMeters, durationSeconds, paceSecondsPerKm, avgHeartRate, cleanRpe, notes?.trim().orEmpty().ifBlank { null }))
        dao.setWorkoutCompleted(workoutId, true)
        markDirty("planned_workouts", workoutId)
        message.value = "Execução registada e treino marcado como concluído."
    }

    fun importExecutionFromHealthConnect(workout: PlannedWorkoutEntity) = viewModelScope.launch(Dispatchers.IO) {
        runCatching {
            val target = java.time.Instant.ofEpochMilli(workout.dateEpochMs)
            val metrics = health.findNearestRunningSession(target) ?: return@runCatching
            val execution = WorkoutExecutionEntity(
                workoutId = workout.id,
                completedAtEpochMs = metrics.end.toEpochMilli(),
                actualDistanceMeters = metrics.distanceMeters.takeIf { it > 0.0 },
                actualDurationSeconds = metrics.durationSeconds.takeIf { it > 0 },
                actualAvgPaceSecondsPerKm = metrics.avgPaceSecondsPerKm,
                actualAvgHeartRate = metrics.avgHeartRate,
                perceivedEffort = null,
                notes = "Importado do Health Connect${metrics.elevationGainMeters?.let { "; elevação ${it.toInt()} m" } ?: ""}"
            )
            dao.upsertWorkoutExecution(execution)
            dao.setWorkoutCompleted(workout.id, true)
            markDirty("planned_workouts", workout.id)
        }
    }


    fun calendarAvailable(): Boolean = ContextCompat.checkSelfPermission(getApplication(), android.Manifest.permission.WRITE_CALENDAR) == PackageManager.PERMISSION_GRANTED && calendar.hasWritableCalendar()

    fun saveGoal(name: String, targetValue: Double, unit: String, deadlineEpochMs: Long? = null) = viewModelScope.launch {
        val goal = GoalEntity(java.util.UUID.randomUUID().toString(), name, targetValue, 0.0, unit, deadlineEpochMs)
        dao.upsertGoal(goal)
        markDirty("goals", goal.id)
        message.value = "Objetivo criado: $name"
    }

    fun exportPlanToCalendar() = viewModelScope.launch {
        if (ContextCompat.checkSelfPermission(getApplication(), android.Manifest.permission.WRITE_CALENDAR) != PackageManager.PERMISSION_GRANTED) {
            message.value = "Permite o acesso ao calendário para exportar o plano."
            return@launch
        }
        val pending = planned.value.take(7).filter { dao.calendarSync(it.id) == null }
        val exported = calendar.exportWeek(pending)
        exported.forEach { dao.upsertCalendarSync(it) }
        message.value = if (exported.isEmpty()) "Nenhum evento foi exportado. Verifica se existe um calendário com escrita ativa." else "${exported.size} treinos enviados para o calendário."
    }
    fun isLoggedIn(): Boolean = api.session() != null
    fun apiBaseUrl(): String = api.baseUrl()
    fun setApiBaseUrl(url: String) = runCatching { api.setBaseUrl(url) }.onSuccess { message.value = "Servidor guardado." }.onFailure { message.value = it.message ?: "URL inválida" }

    fun login(email: String, password: String) = viewModelScope.launch(Dispatchers.IO) {
        runCatching { api.login(email.trim(), password) }
            .onSuccess { loggedIn.value = true; message.value = "Sessão iniciada como ${it.email}." }
            .onFailure { message.value = "Falha no login: ${it.message ?: "erro"}" }
    }

    fun register(email: String, password: String) = viewModelScope.launch(Dispatchers.IO) {
        runCatching { api.register(email.trim(), password) }
            .onSuccess { loggedIn.value = true; message.value = "Conta criada e sessão iniciada." }
            .onFailure { message.value = "Falha no registo: ${it.message ?: "erro"}" }
    }

    fun logout() { api.logout(); loggedIn.value = false; message.value = "Sessão terminada." }

    fun syncCloud() = viewModelScope.launch(Dispatchers.IO) {
        if (!isLoggedIn()) { message.value = "Inicia sessão para sincronizar com a cloud."; return@launch }
        runCatching {
            val pending = dao.syncQueue().filter { it.status == "PENDING" }
            val activityIds = pending.filter { it.entityType == "activities" }.map { it.entityId }.toSet()
            val goalIds = pending.filter { it.entityType == "goals" }.map { it.entityId }.toSet()
            val raceIds = pending.filter { it.entityType == "races" }.map { it.entityId }.toSet()
            val plannedIds = pending.filter { it.entityType == "planned_workouts" }.map { it.entityId }.toSet()
            val activityResult = api.syncActivities(activities.value.filter { it.id in activityIds })
            val goalResult = api.syncGoals(goals.value.filter { it.id in goalIds })
            val raceResult = api.syncRaces(races.value.filter { it.id in raceIds })
            val plannedResult = api.syncPlannedWorkouts(planned.value.filter { it.id in plannedIds })
            dao.upsertActivities(activityResult.pulled)
            dao.upsertGoalList(goalResult.pulled)
            dao.upsertRaces(raceResult.pulled)
            dao.upsertPlannedWorkouts(plannedResult.pulled)
            syncStatus.markSuccess()
            lastSyncEpochMs.value = syncStatus.lastSuccessEpochMs()
            message.value = "Cloud sincronizada: ${activityResult.pushed} treinos, ${goalResult.pushed} objetivos, ${raceResult.pushed} provas e ${plannedResult.pushed} sessões enviados."
        }.onFailure { error ->
            if (error is SessionExpiredException) { loggedIn.value = false; message.value = "Sessão expirada. Inicia sessão novamente." }
            else message.value = "Falha na sincronização cloud: ${error.message ?: "erro"}"
        }
    }

    fun acceptRemoteConflict(conflict: SyncOperationEntity) = viewModelScope.launch(Dispatchers.IO) {
        runCatching {
            val remote = api.fetchCurrent(conflict.entityType, conflict.entityId) ?: throw IllegalStateException("Registo remoto não encontrado")
            when (conflict.entityType) {
                "activities" -> dao.upsertActivities(listOf(remote as ActivityEntity))
                "goals" -> dao.upsertGoal(remote as GoalEntity)
                "races" -> dao.upsertRaces(listOf(remote as RaceEntity))
                "planned_workouts" -> dao.upsertPlannedWorkouts(listOf(remote as PlannedWorkoutEntity))
            }
            dao.deleteSyncOperations(listOf(conflict.operationKey))
            message.value = "Versão cloud aceite: ${conflict.entityId}"
        }.onFailure { message.value = "Não foi possível aceitar a versão cloud: ${it.message ?: "erro"}" }
    }

    fun keepLocalConflict(conflict: SyncOperationEntity) = viewModelScope.launch(Dispatchers.IO) {
        runCatching {
            val local = when (conflict.entityType) {
                "activities" -> activities.value.firstOrNull { it.id == conflict.entityId }
                "goals" -> goals.value.firstOrNull { it.id == conflict.entityId }
                "races" -> races.value.firstOrNull { it.id == conflict.entityId }
                "planned_workouts" -> planned.value.firstOrNull { it.id == conflict.entityId }
                else -> null
            } ?: throw IllegalStateException("Registo local não encontrado")
            api.forceLocal(conflict.entityType, local)
            dao.deleteSyncOperations(listOf(conflict.operationKey))
            message.value = "Versão local reenviada: ${conflict.entityId}"
        }.onFailure { message.value = "Não foi possível manter a versão local: ${it.message ?: "erro"}" }
    }

    fun healthRepository() = health
}
