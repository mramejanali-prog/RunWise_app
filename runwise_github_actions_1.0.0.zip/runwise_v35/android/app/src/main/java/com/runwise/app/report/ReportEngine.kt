package com.runwise.app.report

import com.runwise.app.data.ActivityEntity
import java.time.*
import java.time.temporal.ChronoUnit

object ReportEngine {
    data class Summary(val label: String, val runs: Int, val km: Double, val avgPaceSecKm: Double?, val officialRaces: Int)
    fun summary(activities: List<ActivityEntity>, start: Instant, end: Instant, label: String): Summary {
        val a = activities.filter { it.startedAtEpochMs in start.toEpochMilli() until end.toEpochMilli() }
        val km = a.sumOf { it.distanceMeters } / 1000.0
        val pace = a.mapNotNull { x -> x.avgPaceSecondsPerKm?.let { it to x.distanceMeters } }
        val weighted = pace.sumOf { it.first * it.second } / pace.sumOf { it.second }.coerceAtLeast(1.0)
        return Summary(label, a.size, km, if (pace.isEmpty()) null else weighted, a.count { it.kind.name == "OFFICIAL_RACE" })
    }
    fun allPeriods(activities: List<ActivityEntity>, now: Instant = Instant.now()): List<Summary> {
        val specs = listOf(7L to "Semanal", 14L to "Quinzenal", 30L to "Mensal", 90L to "Trimestral", 180L to "Semestral", 365L to "Anual")
        return specs.map { (days,label) -> summary(activities, now.minus(days, ChronoUnit.DAYS), now.plusSeconds(1), label) }
    }
}
