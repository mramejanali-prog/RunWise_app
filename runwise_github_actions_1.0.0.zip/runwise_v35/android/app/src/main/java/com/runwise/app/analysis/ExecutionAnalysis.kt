package com.runwise.app.analysis

import com.runwise.app.data.PlannedWorkoutEntity
import com.runwise.app.data.WorkoutExecutionEntity
import kotlin.math.abs

object ExecutionAnalysis {
    data class Result(
        val status: String,
        val score: Int,
        val distanceDeltaPct: Double?,
        val durationDeltaPct: Double?,
        val paceDeltaPct: Double?,
        val heartRate: Double?,
        val explanation: String
    )

    fun analyze(plan: PlannedWorkoutEntity, actual: WorkoutExecutionEntity): Result {
        val distanceDelta = pct(actual.actualDistanceMeters, plan.targetDistanceMeters)
        val durationDelta = pct(actual.actualDurationSeconds?.toDouble(), plan.targetDurationSeconds?.toDouble())
        val paceDelta = paceDelta(actual.actualAvgPaceSecondsPerKm, plan.targetPaceMinSecondsPerKm, plan.targetPaceMaxSecondsPerKm)

        var score = 100
        distanceDelta?.let { score -= (abs(it) * 0.7).toInt().coerceAtMost(35) }
        durationDelta?.let { score -= (abs(it) * 0.35).toInt().coerceAtMost(20) }
        paceDelta?.let { score -= (abs(it) * 0.6).toInt().coerceAtMost(25) }
        score = score.coerceIn(0, 100)

        val status = when {
            score >= 85 -> "Dentro do objetivo"
            score >= 65 -> "Próximo do objetivo"
            else -> "Fora do objetivo"
        }
        val parts = mutableListOf<String>()
        distanceDelta?.let { parts += "distância ${signed(it)}%" }
        durationDelta?.let { parts += "duração ${signed(it)}%" }
        paceDelta?.let { parts += "ritmo ${if (it > 0) "mais lento" else "mais rápido"} ${abs(it).format1()}%" }
        val explanation = if (parts.isEmpty()) "Ainda não existem metas numéricas suficientes para comparar este treino." else "Comparação automática: ${parts.joinToString(", ")}."
        return Result(status, score, distanceDelta, durationDelta, paceDelta, actual.actualAvgHeartRate, explanation)
    }

    private fun pct(actual: Double?, target: Double?): Double? = if (actual != null && target != null && target > 0) (actual - target) / target * 100.0 else null

    // Positive means slower than the target range midpoint; negative means faster.
    private fun paceDelta(actual: Double?, min: Double?, max: Double?): Double? {
        if (actual == null) return null
        val target = when {
            min != null && max != null -> (min + max) / 2.0
            min != null -> min
            max != null -> max
            else -> return null
        }
        return (actual - target) / target * 100.0
    }

    private fun signed(v: Double): String = if (v >= 0) "+${v.format1()}" else v.format1()
    private fun Double.format1(): String = "%.1f".format(this)
}
