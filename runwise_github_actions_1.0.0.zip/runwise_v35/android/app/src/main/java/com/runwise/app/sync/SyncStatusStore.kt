package com.runwise.app.sync

import android.content.Context
import java.time.Instant

class SyncStatusStore(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("runwise_sync_status", Context.MODE_PRIVATE)
    fun lastSuccessEpochMs(): Long = prefs.getLong("last_success_epoch_ms", 0L)
    fun markSuccess() = prefs.edit().putLong("last_success_epoch_ms", Instant.now().toEpochMilli()).apply()
}
